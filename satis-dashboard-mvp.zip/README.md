# Satış Performans Dashboardu MVP

Bu proje, Google Sheet’teki satış metriklerini dinamik takip dashboarduna dönüştürmek için hazırlanmış MVP’dir.

## Ne var?

- Genel Bakış
- Ekip bazlı takip: SAS, MoS, TES, SAD
- Satış tipi bazlı takip: Mekan yeni satış, mekan yenileme, TES, SAD
- Insight sayfası
- Manuel güncelleme butonu
- Her gün 19:00’da açık tarayıcıda otomatik refresh
- Excel bulk upload
- Google Apps Script connector örneği

## Çalıştırma

```bash
npm install
npm run dev
```

## Sheet bağlantısı

Frontend önce `VITE_APPS_SCRIPT_URL` varsa onu kullanır. Yoksa Google Sheets CSV endpoint’ini doğrudan okumayı dener.

`.env` örneği:

```bash
VITE_APPS_SCRIPT_URL=https://script.google.com/macros/s/XXXX/exec
```

## Apps Script kurulumu

`apps-script/Code.gs` dosyasındaki kodu Google Sheet > Extensions > Apps Script içine yapıştırın.
Deploy > New deployment > Web app olarak yayınlayın.

## Bulk Excel yükleme

MVP içinde Excel yükleme dashboardu anlık günceller. Sheet’e yazdırmak için Apps Script `doPost` endpoint’i kullanılabilir:

```js
fetch(APPS_SCRIPT_URL, {
  method: "POST",
  body: JSON.stringify({
    token: "DASHBOARD_TOKEN",
    action: "appendRows",
    sheet: "GÜNLÜK_YENİ",
    rows: uploadedRows
  })
})
```

Not: Token’ı frontend’de açık tutmak production için güvenli değildir. Production’da Next.js API route veya şirket içi backend üzerinden saklanmalıdır.

## Kıyaslama mantığı

Ay kapanmadıysa aylık toplam yerine günlük ortalama kıyaslanır. Bu yüzden Mayıs gibi eksik aylar Nisan toplamıyla değil, Nisan günlük ortalamasıyla karşılaştırılır.
