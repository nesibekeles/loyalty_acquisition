import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Line, LineChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis
} from "recharts";
import {
  AlertTriangle, BarChart3, CalendarDays, CheckCircle2, Clock3, Database,
  FileSpreadsheet, Lightbulb, RefreshCw, TrendingDown, TrendingUp, Upload, Users, Wallet
} from "lucide-react";
import * as XLSX from "xlsx";
import "./styles.css";

const SHEET_ID = "1R-rpm5-3yBGGlFzzMIJZbc72gFOZ_-TBahqrH9t5vqs";
const DAILY_SHEET = "GÜNLÜK_YENİ";
const MONTHLY_SHEET = "AYLIK_YENİ";
const UNIT_SHEET = "Metrik Birimleri";
const APPS_SCRIPT_URL = import.meta.env.VITE_APPS_SCRIPT_URL || "";
const BRAND_PINK = "#db0962";
const BRAND_TEAL = "#00ABAA";

const SAMPLE_DAILY = [
  {"Tarih":"1 Nisan 26","SAS Ziyaret adedi (Toplam)":31,"SAS Yeni Ziyaret Adedi":31,"SAS Yenileme Ziyaret Adedi":0,"SAS Ziyaret süresi (Toplam)":1960,"SAS Yeni Ziyaret süresi":1960,"SAS Yenileme Ziyaret süresi":0,"SAS Satış ciroları (Yeni)":487000,"SAS Satış ciroları (Yenileme)":324000,"TES Görüşme adedi":45,"TES Görüşme süresi":241,"TES Satış ciroları (Yeni)":0,"TES Satış ciroları (Yenileme)":0,"SAD Görüşülen firma adedi":143,"SAD Görüşme süresi":248,"SAD Randevu adedi":41,"MOS Ziyaret adedi":0,"MOS Ziyaret süresi":0,"MOS Satış ciroları (Yeni)":0,"SAS Revid adedi (Toplam)":0,"TES Revid adedi (Toplam)":0,"MOS Revid adedi (Toplam)":0,"SAS Satış adedi (Yeni)":0,"SAS Satış adedi (Yenileme)":0,"TES Satış adedi (Yeni)":0,"TES Satış adedi (Yenileme)":0,"MOS Satış adedi (Yeni)":0},
  {"Tarih":"10 Nisan 26","SAS Ziyaret adedi (Toplam)":27,"SAS Yeni Ziyaret Adedi":15,"SAS Yenileme Ziyaret Adedi":12,"SAS Ziyaret süresi (Toplam)":1789,"SAS Yeni Ziyaret süresi":694,"SAS Yenileme Ziyaret süresi":1095,"SAS Satış ciroları (Yeni)":0,"SAS Satış ciroları (Yenileme)":2506098,"TES Görüşme adedi":46,"TES Görüşme süresi":56,"TES Satış ciroları (Yeni)":51750,"TES Satış ciroları (Yenileme)":0,"SAD Görüşülen firma adedi":165,"SAD Görüşme süresi":214,"SAD Randevu adedi":43,"MOS Ziyaret adedi":22,"MOS Ziyaret süresi":777,"MOS Satış ciroları (Yeni)":81000,"SAS Revid adedi (Toplam)":3,"TES Revid adedi (Toplam)":3,"MOS Revid adedi (Toplam)":3,"SAS Satış adedi (Yeni)":0,"SAS Satış adedi (Yenileme)":7,"TES Satış adedi (Yeni)":0,"TES Satış adedi (Yenileme)":1,"MOS Satış adedi (Yeni)":1},
  {"Tarih":"30 Nisan 26","SAS Ziyaret adedi (Toplam)":48,"SAS Yeni Ziyaret Adedi":27,"SAS Yenileme Ziyaret Adedi":21,"SAS Ziyaret süresi (Toplam)":3063,"SAS Yeni Ziyaret süresi":1417,"SAS Yenileme Ziyaret süresi":1646,"SAS Satış ciroları (Yeni)":912816,"SAS Satış ciroları (Yenileme)":1007693,"TES Görüşme adedi":65,"TES Görüşme süresi":257,"TES Satış ciroları (Yeni)":0,"TES Satış ciroları (Yenileme)":0,"SAD Görüşülen firma adedi":258,"SAD Görüşme süresi":275,"SAD Randevu adedi":65,"MOS Ziyaret adedi":25,"MOS Ziyaret süresi":1365,"MOS Satış ciroları (Yeni)":0,"SAS Revid adedi (Toplam)":0,"TES Revid adedi (Toplam)":3,"MOS Revid adedi (Toplam)":3,"SAS Satış adedi (Yeni)":4,"SAS Satış adedi (Yenileme)":5,"TES Satış adedi (Yeni)":0,"TES Satış adedi (Yenileme)":0,"MOS Satış adedi (Yeni)":0},
  {"Tarih":"4 Mayıs 26","SAS Ziyaret adedi (Toplam)":13,"SAS Yeni Ziyaret Adedi":11,"SAS Yenileme Ziyaret Adedi":2,"SAS Ziyaret süresi (Toplam)":770,"SAS Yeni Ziyaret süresi":714,"SAS Yenileme Ziyaret süresi":56,"SAS Satış ciroları (Yeni)":80000,"SAS Satış ciroları (Yenileme)":264000,"TES Görüşme adedi":38,"TES Görüşme süresi":131,"TES Satış ciroları (Yeni)":0,"TES Satış ciroları (Yenileme)":120000,"SAD Görüşülen firma adedi":165,"SAD Görüşme süresi":270,"SAD Randevu adedi":33,"MOS Ziyaret adedi":9,"MOS Ziyaret süresi":308,"MOS Satış ciroları (Yeni)":171600,"SAS Revid adedi (Toplam)":1,"TES Revid adedi (Toplam)":4,"MOS Revid adedi (Toplam)":3,"SAS Satış adedi (Yeni)":2,"SAS Satış adedi (Yenileme)":1,"TES Satış adedi (Yeni)":0,"TES Satış adedi (Yenileme)":2,"MOS Satış adedi (Yeni)":1},
  {"Tarih":"5 Mayıs 26","SAS Ziyaret adedi (Toplam)":22,"SAS Yeni Ziyaret Adedi":9,"SAS Yenileme Ziyaret Adedi":13,"SAS Ziyaret süresi (Toplam)":1763,"SAS Yeni Ziyaret süresi":491,"SAS Yenileme Ziyaret süresi":1272,"SAS Satış ciroları (Yeni)":0,"SAS Satış ciroları (Yenileme)":2478000,"TES Görüşme adedi":56,"TES Görüşme süresi":223,"TES Satış ciroları (Yeni)":0,"TES Satış ciroları (Yenileme)":103500,"SAD Görüşülen firma adedi":102,"SAD Görüşme süresi":170,"SAD Randevu adedi":33,"MOS Ziyaret adedi":10,"MOS Ziyaret süresi":707,"MOS Satış ciroları (Yeni)":248040,"SAS Revid adedi (Toplam)":1,"TES Revid adedi (Toplam)":4,"MOS Revid adedi (Toplam)":3,"SAS Satış adedi (Yeni)":0,"SAS Satış adedi (Yenileme)":5,"TES Satış adedi (Yeni)":0,"TES Satış adedi (Yenileme)":2,"MOS Satış adedi (Yeni)":1}
];

const REVENUE_KEYS = [
  "SAS Satış ciroları (Yeni)", "SAS Satış ciroları (Yenileme)", "MOS Satış ciroları (Yeni)",
  "TES Satış ciroları (Yeni)", "TES Satış ciroları (Yenileme)"
];

const TEAM_DEFINITIONS = {
  SAS: {label:"SAS / Saha Satış", desc:"Mekan kategorilerinde saha satış. İstanbul’da 6 Nisan sonrası ağırlık yenileme.", revenue:["SAS Satış ciroları (Yeni)","SAS Satış ciroları (Yenileme)"], activity:["SAS Ziyaret adedi (Toplam)","SAS Yeni Ziyaret Adedi","SAS Yenileme Ziyaret Adedi"], sales:["SAS Satış adedi (Yeni)","SAS Satış adedi (Yenileme)"]},
  MOS: {label:"MoS / Mekan Yeni Satış", desc:"Yeni satış odaklı mekan ekibi. Şu an İstanbul ağırlıklı.", revenue:["MOS Satış ciroları (Yeni)"], activity:["MOS Ziyaret adedi"], sales:["MOS Satış adedi (Yeni)"]},
  TES: {label:"TES / Tele Satış", desc:"Mekan dışı kategoriler ve tele satış; yeni + yenileme birlikte takip edilir.", revenue:["TES Satış ciroları (Yeni)","TES Satış ciroları (Yenileme)"], activity:["TES Görüşme adedi"], sales:["TES Satış adedi (Yeni)","TES Satış adedi (Yenileme)"]},
  SAD: {label:"SAD / Randevu Ekibi", desc:"Ciro dışı takip. Ana metrik görüşülen firma ve randevu adedi.", revenue:[], activity:["SAD Görüşülen firma adedi","SAD Randevu adedi"], sales:[]}
};

const monthMap = {Ocak:0, Şubat:1, Mart:2, Nisan:3, Mayıs:4, Haziran:5, Temmuz:6, Ağustos:7, Eylül:8, Ekim:9, Kasım:10, Aralık:11};

function parseCSV(text) {
  const lines = text.trim().split(/\r?\n/);
  const rows = [];
  let row = [], cell = "", quoted = false;
  for (const line of lines) {
    row = []; cell = ""; quoted = false;
    for (let i=0;i<line.length;i++) {
      const c = line[i], next = line[i+1];
      if (c === '"' && quoted && next === '"') { cell += '"'; i++; }
      else if (c === '"') quoted = !quoted;
      else if (c === "," && !quoted) { row.push(cell); cell = ""; }
      else cell += c;
    }
    row.push(cell); rows.push(row);
  }
  const headers = rows[0].map(h => h.trim());
  return rows.slice(1).filter(r => r.some(Boolean)).map(r => {
    const obj = {};
    headers.forEach((h,i) => {
      const raw = (r[i] ?? "").trim();
      const normalized = raw.replace(/\./g, "").replace(/,/g, ".");
      const num = Number(normalized);
      obj[h] = raw !== "" && !Number.isNaN(num) ? num : raw;
    });
    return obj;
  });
}

function parseTRDate(v) {
  const parts = String(v || "").trim().split(/\s+/);
  if (parts.length < 3) return null;
  const day = Number(parts[0]), month = monthMap[parts[1]], year = Number(parts[2]) < 100 ? 2000 + Number(parts[2]) : Number(parts[2]);
  if (!day || month === undefined || !year) return null;
  return new Date(year, month, day);
}
function monthKey(date) { return date ? `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}` : "Bilinmiyor"; }
function prettyMonth(key) {
  if (!key || key === "Bilinmiyor") return key;
  const [year, month] = key.split("-").map(Number);
  const name = Object.keys(monthMap).find(k => monthMap[k] === month - 1);
  return `${name} ${year}`;
}
function n(row, key) { const v = Number(row?.[key] ?? 0); return Number.isFinite(v) ? v : 0; }
function sumRows(rows, keys) { return rows.reduce((t,row)=>t+keys.reduce((s,k)=>s+n(row,k),0),0); }
function changeRate(current, previous) { if (!previous) return current ? 100 : 0; return ((current - previous) / previous) * 100; }
function fmt(value, unit="adet") {
  const safe = Number(value || 0);
  if (unit === "TL") return new Intl.NumberFormat("tr-TR", {style:"currency", currency:"TRY", maximumFractionDigits:0}).format(safe);
  return safe.toLocaleString("tr-TR", {maximumFractionDigits:1});
}
async function fetchDashboardData() {
  if (APPS_SCRIPT_URL) {
    const res = await fetch(`${APPS_SCRIPT_URL}?action=all`, {cache:"no-store"});
    if (!res.ok) throw new Error("Apps Script okunamadı");
    return await res.json();
  }
  const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(DAILY_SHEET)}`;
  const res = await fetch(url, {cache:"no-store"});
  if (!res.ok) throw new Error("Sheet okunamadı");
  return {daily: parseCSV(await res.text()), monthly: [], units: []};
}

function Card({title, value, prev, unit, icon:Icon, hint}) {
  const delta = changeRate(value, prev);
  const cls = delta >= 10 ? "good" : delta <= -10 ? "bad" : "flat";
  return <div className="card metric">
    <div className="metricTop"><div><p>{title}</p><h3>{fmt(value, unit)}</h3></div><span className="icon"><Icon size={20}/></span></div>
    <div className="metricBottom"><span className={`pill ${cls}`}>{delta > 0 ? "+" : ""}{delta.toFixed(1)}%</span><small>{hint}</small></div>
  </div>
}

function App() {
  const [daily, setDaily] = useState(SAMPLE_DAILY);
  const [tab, setTab] = useState("overview");
  const [selectedMonth, setSelectedMonth] = useState("all");
  const [teamFilter, setTeamFilter] = useState("all");
  const [status, setStatus] = useState("Örnek veri ile açıldı. Sheet bağlantısı deneniyor.");
  const [loading, setLoading] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(null);
  const autoGuard = useRef("");

  const normalized = useMemo(() => daily.map(r => ({...r, __date: parseTRDate(r.Tarih)})).filter(r => r.__date).map(r => ({...r, __month: monthKey(r.__date)})).sort((a,b)=>a.__date-b.__date), [daily]);
  const months = useMemo(() => [...new Set(normalized.map(r => r.__month))], [normalized]);
  const latestMonth = months[months.length - 1], previousMonth = months[months.length - 2];
  const latestRows = normalized.filter(r => r.__month === latestMonth);
  const prevRows = normalized.filter(r => r.__month === previousMonth);
  const filteredRows = selectedMonth === "all" ? normalized : normalized.filter(r => r.__month === selectedMonth);
  const latestDayCount = Math.max(latestRows.length, 1), prevDayCount = Math.max(prevRows.length, 1);
  const compareAverage = latestMonth === monthKey(new Date());

  async function refresh() {
    setLoading(true); setStatus("Veriler güncelleniyor...");
    try {
      const data = await fetchDashboardData();
      if (data.daily?.length) setDaily(data.daily);
      setLastRefresh(new Date());
      setStatus("Sheet bağlantısı aktif. Veriler güncellendi.");
    } catch(e) {
      setStatus("Sheet doğrudan okunamadı; örnek veri gösteriliyor. Üretimde Apps Script/Backend proxy önerilir.");
    } finally { setLoading(false); }
  }
  useEffect(() => { refresh(); }, []);
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const key = `${now.toDateString()}-${now.getHours()}-${now.getMinutes()}`;
      if (now.getHours() === 19 && now.getMinutes() === 0 && autoGuard.current !== key) {
        autoGuard.current = key; refresh();
      }
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  function uploadExcel(e) {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const wb = XLSX.read(new Uint8Array(ev.target.result), {type:"array"});
      const sheetName = wb.SheetNames.find(n => n.toLowerCase().includes("günlük")) || wb.SheetNames[0];
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], {defval:0});
      setDaily(rows);
      setStatus(`${file.name} yüklendi. ${sheetName} sayfasından ${rows.length} satır okundu.`);
      setLastRefresh(new Date());
    };
    reader.readAsArrayBuffer(file);
  }

  const chartRows = filteredRows.map(r => ({
    date: String(r.Tarih).replace(" 26",""),
    mekanYeniCiro: n(r,"SAS Satış ciroları (Yeni)") + n(r,"MOS Satış ciroları (Yeni)"),
    yenilemeCiro: n(r,"SAS Satış ciroları (Yenileme)"),
    tesCiro: n(r,"TES Satış ciroları (Yeni)") + n(r,"TES Satış ciroları (Yenileme)"),
    sadRandevu: n(r,"SAD Randevu adedi"),
    sasZiyaret: n(r,"SAS Ziyaret adedi (Toplam)"),
    mosZiyaret: n(r,"MOS Ziyaret adedi"),
    tesGorusme: n(r,"TES Görüşme adedi")
  }));

  const currentRevenue = sumRows(latestRows, REVENUE_KEYS);
  const prevRevenue = sumRows(prevRows, REVENUE_KEYS);
  const currentRevenueComparable = compareAverage ? currentRevenue / latestDayCount : currentRevenue;
  const prevRevenueComparable = compareAverage ? prevRevenue / prevDayCount : prevRevenue;

  const monthlyComparison = months.map(key => {
    const rows = normalized.filter(r => r.__month === key);
    return {
      month: prettyMonth(key),
      gunlukOrtalamaCiro: sumRows(rows, REVENUE_KEYS) / Math.max(rows.length,1),
      sadRandevu: sumRows(rows, ["SAD Randevu adedi"])
    };
  });

  const teamCards = Object.entries(TEAM_DEFINITIONS).map(([team, def]) => ({
    team, ...def,
    revenue: sumRows(filteredRows, def.revenue),
    activity: sumRows(filteredRows, def.activity),
    sales: sumRows(filteredRows, def.sales)
  })).filter(c => teamFilter === "all" || c.team === teamFilter);

  const salesTypes = [
    {type:"Mekan Yeni Satış", owner:"SAS + MoS", revenue:sumRows(filteredRows,["SAS Satış ciroları (Yeni)","MOS Satış ciroları (Yeni)"]), activity:sumRows(filteredRows,["SAS Yeni Ziyaret Adedi","MOS Ziyaret adedi"]), sales:sumRows(filteredRows,["SAS Satış adedi (Yeni)","MOS Satış adedi (Yeni)"]), focus:"MoS büyüdükçe yeni satışın ana sahibi MoS olmalı; SAS yeni satış verisi geçiş dönemi olarak izlenmeli."},
    {type:"Mekan Yenileme", owner:"SAS", revenue:sumRows(filteredRows,["SAS Satış ciroları (Yenileme)"]), activity:sumRows(filteredRows,["SAS Yenileme Ziyaret Adedi"]), sales:sumRows(filteredRows,["SAS Satış adedi (Yenileme)"]), focus:"Nisan 6 sonrası İstanbul SAS odağı yenileme olduğu için ziyaret → satış verimi ayrıca takip edilmeli."},
    {type:"TES Yeni + Yenileme", owner:"TES", revenue:sumRows(filteredRows,["TES Satış ciroları (Yeni)","TES Satış ciroları (Yenileme)"]), activity:sumRows(filteredRows,["TES Görüşme adedi"]), sales:sumRows(filteredRows,["TES Satış adedi (Yeni)","TES Satış adedi (Yenileme)"]), focus:"Mekan dışı kategori sağlığı için takip edilir; ana mekan stratejisinden ayrı yorumlanmalı."},
    {type:"SAD Randevu Üretimi", owner:"SAD", revenue:0, activity:sumRows(filteredRows,["SAD Görüşülen firma adedi"]), sales:sumRows(filteredRows,["SAD Randevu adedi"]), focus:"Ciro değil, randevu üretimi ve görüşme → randevu dönüşümü ana başarı göstergesi."}
  ];

  const insights = [
    {name:"Mekan yeni satış cirosu", keys:["SAS Satış ciroları (Yeni)","MOS Satış ciroları (Yeni)"], unit:"TL", action:"MoS pipeline doluluğu, yeni satış randevu kalitesi ve SAS → MoS lead devri kontrol edilmeli."},
    {name:"Mekan yenileme cirosu", keys:["SAS Satış ciroları (Yenileme)"], unit:"TL", action:"Yenileme ayı gelen firmalar için erken randevu, performans raporu ve itiraz kırılımı çıkarılmalı."},
    {name:"SAD randevu adedi", keys:["SAD Randevu adedi"], unit:"adet", action:"Görüşme hacmi aynı kalıp randevu düşüyorsa script, lead kalitesi ve itiraz kategorileri birlikte incelenmeli."},
    {name:"SAS ziyaret hacmi", keys:["SAS Ziyaret adedi (Toplam)"], unit:"adet", action:"Ziyaret düşüşü varsa saha kapasitesi, il dağılımı ve yenileme/yeni ziyaret dengesi kontrol edilmeli."}
  ].map(i => {
    const current = sumRows(latestRows, i.keys) / latestDayCount;
    const previous = sumRows(prevRows, i.keys) / prevDayCount;
    const rate = changeRate(current, previous);
    return {...i, current, previous, rate, status: rate >= 15 ? "good" : rate <= -15 ? "risk" : "watch"};
  });

  return <div className="page">
    <header className="hero">
      <div>
        <span className="heroBadge"><Database size={14}/> Google Sheet bağlantılı satış takip paneli</span>
        <h1>Satış Performans Dashboardu</h1>
        <p>SAS, MoS, TES ve SAD metriklerini günlük/aylık, ekip ve satış tipi kırılımlarında takip eder. Ay kapanmadığında aylık kıyasları toplam yerine günlük ortalama üzerinden yorumlar.</p>
      </div>
      <div className="actions">
        <button onClick={refresh} className="btn white"><RefreshCw size={16} className={loading ? "spin" : ""}/> Manuel Güncelle</button>
        <label className="btn pink"><Upload size={16}/> Excel Yükle<input type="file" accept=".xlsx,.xls,.csv" onChange={uploadExcel}/></label>
      </div>
    </header>

    <section className="toolbar">
      <div className="tabs">
        {[
          ["overview","Genel Bakış",BarChart3],
          ["teams","Ekipler",Users],
          ["salesTypes","Satış Tipleri",Wallet],
          ["insights","Insight",Lightbulb],
          ["data","Veri Girişi",FileSpreadsheet],
        ].map(([key,label,Icon]) => <button key={key} onClick={()=>setTab(key)} className={tab === key ? "active" : ""}><Icon size={16}/>{label}</button>)}
      </div>
      <div className="filters">
        <select value={selectedMonth} onChange={e=>setSelectedMonth(e.target.value)}>
          <option value="all">Tüm aylar</option>
          {months.map(m => <option key={m} value={m}>{prettyMonth(m)}</option>)}
        </select>
        <select value={teamFilter} onChange={e=>setTeamFilter(e.target.value)}>
          <option value="all">Tüm ekipler</option>
          {Object.keys(TEAM_DEFINITIONS).map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>
    </section>

    <div className="status"><Clock3 size={16}/><span>{status}</span><b>Son güncelleme: {lastRefresh ? lastRefresh.toLocaleString("tr-TR") : "-"}</b><b>Otomatik: 19:00</b></div>

    {tab === "overview" && <main>
      <Title eyebrow="Genel metrik takibi" title="Son ay performansı ve önceki ay kıyası" subtitle={compareAverage ? "Ay henüz kapanmadığı için son ay ile önceki ay günlük ortalama üzerinden kıyaslanır." : "Ay kapanmışsa toplam performans üzerinden kıyaslanır."} icon={CalendarDays}/>
      <div className="metricGrid">
        <Card title={compareAverage ? "Günlük Ortalama Toplam Ciro" : "Toplam Ciro"} value={currentRevenueComparable} prev={prevRevenueComparable} unit="TL" icon={Wallet} hint={`${prettyMonth(latestMonth)} vs ${prettyMonth(previousMonth)}`}/>
        <Card title="Mekan Yeni Ciro" value={sumRows(latestRows,["SAS Satış ciroları (Yeni)","MOS Satış ciroları (Yeni)"]) / (compareAverage ? latestDayCount : 1)} prev={sumRows(prevRows,["SAS Satış ciroları (Yeni)","MOS Satış ciroları (Yeni)"]) / (compareAverage ? prevDayCount : 1)} unit="TL" icon={TrendingUp} hint="SAS + MoS"/>
        <Card title="Mekan Yenileme Ciro" value={sumRows(latestRows,["SAS Satış ciroları (Yenileme)"]) / (compareAverage ? latestDayCount : 1)} prev={sumRows(prevRows,["SAS Satış ciroları (Yenileme)"]) / (compareAverage ? prevDayCount : 1)} unit="TL" icon={CheckCircle2} hint="SAS yenileme"/>
        <Card title="SAD Randevu" value={sumRows(latestRows,["SAD Randevu adedi"]) / (compareAverage ? latestDayCount : 1)} prev={sumRows(prevRows,["SAD Randevu adedi"]) / (compareAverage ? prevDayCount : 1)} unit="adet" icon={Users} hint="Randevu üretimi"/>
      </div>
      <div className="chartGrid">
        <div className="card wide">
          <h3>Günlük Ciro Trendi</h3><p>Mekan yeni, yenileme ve TES ciro ayrımı</p>
          <ChartArea chartRows={chartRows}/>
        </div>
        <div className="card">
          <h3>Aylık Kıyas</h3><p>Kapanmamış aylar günlük ortalama ile okunmalı.</p>
          <div className="chartH"><ResponsiveContainer><BarChart data={monthlyComparison}><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="month" tick={{fontSize:11}}/><YAxis tick={{fontSize:11}}/><Tooltip formatter={v=>fmt(v,"TL")}/><Bar dataKey="gunlukOrtalamaCiro" name="Günlük Ortalama Ciro" fill={BRAND_PINK} radius={[10,10,0,0]}/></BarChart></ResponsiveContainer></div>
        </div>
      </div>
    </main>}

    {tab === "teams" && <main>
      <Title eyebrow="Ekip bazlı takip" title="SAS, MoS, TES ve SAD kırılımı" subtitle="Ciro ekipleri ve ciro dışı SAD randevu üretimi ayrı mantıkla yorumlanır." icon={Users}/>
      <div className="teamGrid">{teamCards.map(c => <div className="card" key={c.team}><div className="teamHeader"><div><small>{c.team}</small><h3>{c.label}</h3></div><Users/></div><p>{c.desc}</p><div className="miniStats"><span>Ciro <b>{fmt(c.revenue,"TL")}</b></span><span>Aktivite <b>{fmt(c.activity)}</b></span><span>Satış/Randevu <b>{fmt(c.sales)}</b></span></div></div>)}</div>
      <div className="card wide"><h3>Aktivite Trendi</h3><p>SAS ziyaret, MoS ziyaret, TES görüşme ve SAD randevu günlük değişimi</p><div className="chartH"><ResponsiveContainer><LineChart data={chartRows}><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="date" tick={{fontSize:11}}/><YAxis tick={{fontSize:11}}/><Tooltip/><Line type="monotone" dataKey="sasZiyaret" name="SAS ziyaret" stroke={BRAND_PINK} strokeWidth={2} dot={false}/><Line type="monotone" dataKey="mosZiyaret" name="MoS ziyaret" stroke={BRAND_TEAL} strokeWidth={2} dot={false}/><Line type="monotone" dataKey="tesGorusme" name="TES görüşme" stroke="#64748b" strokeWidth={2} dot={false}/><Line type="monotone" dataKey="sadRandevu" name="SAD randevu" stroke="#f59e0b" strokeWidth={2} dot={false}/></LineChart></ResponsiveContainer></div></div>
    </main>}

    {tab === "salesTypes" && <main>
      <Title eyebrow="Satış tipi bazlı takip" title="Yeni satış, yenileme, TES ve SAD ayrımı" subtitle="Ana mekan stratejisini SAS/MoS yeni satış ve SAS yenileme olarak; TES’i ayrı iş kolu, SAD’ı randevu üretimi olarak okur." icon={Wallet}/>
      <div className="salesGrid">{salesTypes.map(s => <div className="card" key={s.type}><h3>{s.type}</h3><strong>Sahip: {s.owner}</strong><div className="miniStats three"><span>Ciro <b>{fmt(s.revenue,"TL")}</b></span><span>Aktivite <b>{fmt(s.activity)}</b></span><span>Satış/Randevu <b>{fmt(s.sales)}</b></span></div><p>{s.focus}</p></div>)}</div>
    </main>}

    {tab === "insights" && <main>
      <Title eyebrow="Insight & aksiyon" title="Düşen / iyi giden metrikler ve önerilen aksiyonlar" subtitle="Son ayın günlük ortalaması önceki ayın günlük ortalamasıyla kıyaslanır. ±%15 üzeri değişimler sinyal üretir." icon={Lightbulb}/>
      <div className="insightList">{insights.map(i => {
        const Icon = i.status === "good" ? TrendingUp : i.status === "risk" ? TrendingDown : AlertTriangle;
        return <div className={`card insight ${i.status}`} key={i.name}><Icon/><div><h3>{i.name}</h3><p>Günlük ortalama: <b>{fmt(i.current,i.unit)}</b> / Önceki ay: <b>{fmt(i.previous,i.unit)}</b></p><p>{i.action}</p></div><span>{i.rate > 0 ? "+" : ""}{i.rate.toFixed(1)}%</span></div>
      })}</div>
    </main>}

    {tab === "data" && <main>
      <Title eyebrow="Veri girişi" title="Sheet bağlantısı + bulk Excel yükleme" subtitle="Dashboard linkteki Google Sheet’i okumaya çalışır. Excel yükleme butonu aynı formatta gelen dosyayı anlık olarak panele basar." icon={FileSpreadsheet}/>
      <div className="dataGrid">
        <div className="card wide"><h3>Bağlantı bilgileri</h3><div className="codeBox"><b>Sheet ID:</b> {SHEET_ID}</div><div className="codeBox"><b>Günlük veri:</b> {DAILY_SHEET}</div><div className="codeBox"><b>Aylık veri:</b> {MONTHLY_SHEET}</div><div className="warning"><b>Not:</b> Google Sheets doğrudan fetch ile okunamazsa sebep genelde CORS veya dosya izinleridir. En sağlam çözüm Apps Script veya backend proxy kullanmaktır.</div></div>
        <div className="card"><h3>Bulk Excel</h3><p>Aynı kolon yapısındaki Excel dosyasını yükleyerek dashboardu anında güncelleyebilirsin.</p><label className="drop"><Upload/>Excel dosyası seç<input type="file" accept=".xlsx,.xls,.csv" onChange={uploadExcel}/></label></div>
      </div>
    </main>}
  </div>
}

function Title({eyebrow,title,subtitle,icon:Icon}) {
  return <div className="sectionTitle"><div><span><Icon size={14}/>{eyebrow}</span><h2>{title}</h2><p>{subtitle}</p></div></div>
}
function ChartArea({chartRows}) {
  return <div className="chartH"><ResponsiveContainer><AreaChart data={chartRows}><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="date" tick={{fontSize:11}}/><YAxis tick={{fontSize:11}}/><Tooltip formatter={v=>fmt(v,"TL")}/><Area type="monotone" dataKey="mekanYeniCiro" name="Mekan Yeni" stroke={BRAND_PINK} fill={BRAND_PINK} fillOpacity={0.15}/><Area type="monotone" dataKey="yenilemeCiro" name="Yenileme" stroke={BRAND_TEAL} fill={BRAND_TEAL} fillOpacity={0.15}/><Area type="monotone" dataKey="tesCiro" name="TES" stroke="#64748b" fill="#64748b" fillOpacity={0.12}/></AreaChart></ResponsiveContainer></div>
}

createRoot(document.getElementById("root")).render(<App />);
