/**
 * Google Apps Script connector for Satış Performans Dashboardu
 *
 * Kurulum:
 * 1) Google Sheet içinde Extensions > Apps Script açın.
 * 2) Bu dosyayı Code.gs olarak yapıştırın.
 * 3) Project Settings > Script Properties içine DASHBOARD_TOKEN ekleyin.
 * 4) Deploy > New deployment > Web app:
 *    - Execute as: Me
 *    - Who has access: kurum içi veya Anyone with the link
 * 5) Web app URL'ini frontend .env dosyasında VITE_APPS_SCRIPT_URL olarak tanımlayın.
 */

const SPREADSHEET_ID = '1R-rpm5-3yBGGlFzzMIJZbc72gFOZ_-TBahqrH9t5vqs';
const DAILY_SHEET = 'GÜNLÜK_YENİ';
const MONTHLY_SHEET = 'AYLIK_YENİ';
const UNIT_SHEET = 'Metrik Birimleri';

function doGet(e) {
  const action = e.parameter.action || 'all';
  if (action === 'all') {
    return jsonOutput({
      daily: readSheetAsObjects_(DAILY_SHEET),
      monthly: readSheetAsObjects_(MONTHLY_SHEET),
      units: readSheetAsObjects_(UNIT_SHEET),
      refreshedAt: new Date().toISOString()
    });
  }

  const sheetName = e.parameter.sheet || DAILY_SHEET;
  return jsonOutput({
    sheet: sheetName,
    rows: readSheetAsObjects_(sheetName),
    refreshedAt: new Date().toISOString()
  });
}

function doPost(e) {
  const body = JSON.parse(e.postData.contents || '{}');
  const token = PropertiesService.getScriptProperties().getProperty('DASHBOARD_TOKEN');

  if (!token || body.token !== token) {
    return jsonOutput({ ok: false, error: 'Unauthorized token' });
  }

  if (body.action === 'appendRows') {
    const result = appendRows_(body.sheet || DAILY_SHEET, body.rows || []);
    return jsonOutput({ ok: true, ...result });
  }

  if (body.action === 'replaceRows') {
    const result = replaceRows_(body.sheet || DAILY_SHEET, body.rows || []);
    return jsonOutput({ ok: true, ...result });
  }

  return jsonOutput({ ok: false, error: 'Unknown action' });
}

function readSheetAsObjects_(sheetName) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet) throw new Error('Sheet not found: ' + sheetName);

  const values = sheet.getDataRange().getDisplayValues();
  if (values.length < 2) return [];

  const headers = values[0].map(String);
  return values.slice(1)
    .filter(row => row.some(cell => String(cell).trim() !== ''))
    .map(row => {
      const obj = {};
      headers.forEach((header, index) => obj[header] = row[index] || '');
      return obj;
    });
}

function appendRows_(sheetName, rows) {
  if (!rows.length) return { added: 0 };
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName(sheetName);
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getDisplayValues()[0];

  const values = rows.map(row => headers.map(header => row[header] ?? ''));
  sheet.getRange(sheet.getLastRow() + 1, 1, values.length, headers.length).setValues(values);
  return { added: values.length };
}

function replaceRows_(sheetName, rows) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName(sheetName);
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getDisplayValues()[0];

  if (sheet.getLastRow() > 1) {
    sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).clearContent();
  }

  if (!rows.length) return { replaced: 0 };
  const values = rows.map(row => headers.map(header => row[header] ?? ''));
  sheet.getRange(2, 1, values.length, headers.length).setValues(values);
  return { replaced: values.length };
}

function createDailyRefreshTrigger() {
  ScriptApp.newTrigger('touchDashboardRefresh_')
    .timeBased()
    .atHour(19)
    .everyDays(1)
    .inTimezone('Europe/Istanbul')
    .create();
}

function touchDashboardRefresh_() {
  PropertiesService.getScriptProperties().setProperty('LAST_REFRESH_AT', new Date().toISOString());
  SpreadsheetApp.flush();
}

function jsonOutput(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}
